import ttkbootstrap as ttk
from ttkbootstrap.constants import *
import sqlite3
from datetime import datetime
import os
from tkinter import messagebox
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from tkcalendar import DateEntry
import shutil
from PIL import Image, ImageDraw, ImageFont
import io
import base64
from datetime import datetime, timedelta
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.drawing.image import Image
from os_interna_andamento import criar_os_interna_andamento, criar_os_ziehm

# Importar o módulo para gerar a OS interna de andamento
try:
    from os_interna_andamento import criar_os_interna_andamento
except ImportError:
    print("Módulo os_interna_andamento não encontrado, algumas funcionalidades estarão indisponíveis")

class MoracaOS:
    def __init__(self):
        self.root = ttk.Window(themename="solar")
        self.root.title("Moraca - Sistema de OS")
        self.root.geometry("800x600")
        
        # Criar estrutura de pastas
        self.criar_estrutura_pastas()
        
        # Verificar e copiar logo se necessário
        self.verificar_logo()
        
        # Criar banco de dados
        self.criar_banco()
        
        # Frame principal
        self.main_frame = ttk.Frame(self.root, padding="20")
        self.main_frame.pack(fill=BOTH, expand=YES)
        
        # Título
        ttk.Label(
            self.main_frame,
            text="Moraca - Sistema de Ordem de Serviço",
            font=("Helvetica", 16, "bold")
        ).pack(pady=20)
        
        # Frame para botões
        self.button_frame = ttk.Frame(self.main_frame)
        self.button_frame.pack(pady=20)
        
        # Botão principal
        ttk.Button(
            self.button_frame,
            text="Nova OS",
            command=self.criar_nova_os,
            style="primary.TButton",
            width=30
        ).pack(pady=10)
        
        # Botão para gerar OS interna de andamento
        ttk.Button(
            self.button_frame,
            text="Gerar OS Interna de Andamento",
            command=self.gerar_os_interna_andamento,
            style="secondary.TButton",
            width=30
        ).pack(pady=10)
        
        # Frame para pesquisa
        self.search_frame = ttk.Frame(self.main_frame)
        self.search_frame.pack(pady=20)
        
        ttk.Label(
            self.search_frame,
            text="Pesquisar OS:"
        ).pack(side=LEFT, padx=5)
        
        self.search_entry = ttk.Entry(self.search_frame, width=30)
        self.search_entry.pack(side=LEFT, padx=5)
        
        ttk.Button(
            self.search_frame,
            text="Buscar",
            command=self.buscar_os,
            style="secondary.TButton"
        ).pack(side=LEFT, padx=5)
        
        # Lista de últimas OS
        self.lista_frame = ttk.Frame(self.main_frame)
        self.lista_frame.pack(fill=BOTH, expand=YES, pady=20)
        
        ttk.Label(
            self.lista_frame,
            text="Últimas OS Criadas",
            font=("Helvetica", 12, "bold")
        ).pack(pady=10)
        
        # Criar tabela
        self.tabela = ttk.Treeview(
            self.lista_frame,
            columns=("numero", "cliente", "data", "status"),
            show="headings"
        )
        
        self.tabela.heading("numero", text="Número")
        self.tabela.heading("cliente", text="Cliente")
        self.tabela.heading("data", text="Data")
        self.tabela.heading("status", text="Status")
        
        self.tabela.pack(fill=BOTH, expand=YES)
        
        # Atualizar lista
        self.atualizar_lista()
    
    def criar_estrutura_pastas(self):
        # Criar pasta principal se não existir
        if not os.path.exists("OSs"):
            os.makedirs("OSs")
        
        # Criar subpastas se não existirem
        subpastas = ["Pendentes", "Em_Andamento", "Concluidas"]
        for subpasta in subpastas:
            if not os.path.exists(os.path.join("OSs", subpasta)):
                os.makedirs(os.path.join("OSs", subpasta))
    
    def verificar_logo(self):
        """Verifica se a logo existe na pasta assets, se não existir, cria uma logo placeholder"""
        if not os.path.exists("assets"):
            os.makedirs("assets")
            
        logo_path = os.path.join("assets", "logo.png")
        if not os.path.exists(logo_path):
            try:
                # Criar uma logo placeholder
                from PIL import Image, ImageDraw, ImageFont
                
                # Criar uma imagem com fundo branco
                img = Image.new('RGB', (400, 100), color=(255, 255, 255))
                draw = ImageDraw.Draw(img)
                
                # Desenhar texto
                draw.text((10, 40), "MORACA SISTEMAS", fill=(0, 0, 0))
                
                # Salvar a imagem
                img.save(logo_path)
                print("Foi criada uma imagem placeholder em assets/logo.png")
                print("Substitua essa imagem pela logo real antes de usar o sistema")
            except Exception as e:
                print(f"Erro ao criar logo placeholder: {e}")
                print("Arquivo logo.png não encontrado!")
                print("Por favor, salve a imagem da logo em assets/logo.png")
                print("A imagem deve ter o formato PNG e resolução adequada")
                print("Após salvar a imagem no local correto, execute o programa novamente")
    
    def criar_banco(self):
        conn = sqlite3.connect('moraca.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS os
                    (numero TEXT PRIMARY KEY,
                     cliente TEXT,
                     maquina TEXT,
                     descricao TEXT,
                     urgencia TEXT,
                     data TEXT,
                     status TEXT,
                     tipo TEXT,
                     patrimonio TEXT,
                     numero_serie TEXT,
                     local TEXT,
                     endereco TEXT,
                     telefone TEXT,
                     cep TEXT,
                     contato_nome TEXT,
                     contato_telefone1 TEXT,
                     contato_telefone2 TEXT,
                     descricao_servico TEXT,
                     necessita_viagem TEXT,
                     tipo_hospedagem TEXT,
                     prazo_entrega TEXT,
                     empresa TEXT)''')
        conn.commit()
        
        # Verificar se a coluna 'empresa' existe, e adicionar se não existir
        c.execute("PRAGMA table_info(os)")
        colunas = [info[1] for info in c.fetchall()]
        if 'empresa' not in colunas:
            try:
                c.execute("ALTER TABLE os ADD COLUMN empresa TEXT")
                print("Coluna 'empresa' adicionada com sucesso ao banco de dados.")
                conn.commit()
            except sqlite3.OperationalError as e:
                print(f"Erro ao adicionar coluna 'empresa': {e}")
        
        conn.close()
    
    def gerar_arquivo_excel_os(self, numero, cliente, maquina, descricao, urgencia, data, status, tipo,
                        patrimonio, numero_serie, local, endereco, telefone, cep,
                        contato_nome, contato_telefone1, contato_telefone2, descricao_servico,
                        necessita_viagem, tipo_hospedagem, prazo_entrega, empresa):
        # Criar uma nova planilha
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = f"OS {numero}"
        
        # Ajustar a altura da linha
        ws.row_dimensions[1].height = 25
        
        # Configurar larguras das colunas
        ws.column_dimensions['A'].width = 15
        ws.column_dimensions['B'].width = 15
        ws.column_dimensions['C'].width = 15  # Ajustei para ter 3 colunas iguais
        ws.column_dimensions['D'].width = 30  # Aumentada para a célula do prazo de entrega
        ws.column_dimensions['E'].width = 20  # Aumentada para a célula do prazo de entrega
        
        # Ajustar a altura da linha do prazo
        ws.row_dimensions[3].height = 30  # Altura aumentada para a linha do prazo
        
        # Definir estilos
        titulo_font = Font(name='Arial', size=16, bold=True)
        cabecalho_font = Font(name='Arial', size=11, bold=True)
        normal_font = Font(name='Arial', size=10)
        center_align = Alignment(horizontal='center', vertical='center')
        left_align = Alignment(horizontal='left', vertical='center')
        
        # Borda mais espessa para compatibilidade com LibreOffice
        medium_border = Border(
            left=Side(style='medium'),
            right=Side(style='medium'),
            top=Side(style='medium'),
            bottom=Side(style='medium')
        )
        
        # Fundo preto para o cabeçalho
        black_fill = PatternFill(start_color='000000', end_color='000000', fill_type='solid')
        
        # Cabeçalho - O.S.I
        ws.merge_cells('A1:E1')
        ws['A1'] = f"O.S.I. - {empresa}"
        ws['A1'].font = Font(name='Arial', size=16, bold=True, color='FFFFFF')
        ws['A1'].alignment = left_align
        ws['A1'].fill = black_fill
        
        # Número da OS - Modificado para mesclar A2:C2 e D2:E2 separadamente
        ws.merge_cells('A2:C2')
        ws.merge_cells('D2:E2')
        
        ws['A2'] = numero
        ws['A2'].font = titulo_font
        ws['A2'].alignment = left_align
        
        # Adicionar logo na célula D2:E2 em vez de texto
        # ws['D2'] = "Nº OS"
        # ws['D2'].font = cabecalho_font
        # ws['D2'].alignment = center_align
        
        # Carregar e adicionar a imagem do logo
        if os.path.exists(os.path.join("assets", "logo.png")):
            # Ajustar altura da linha para acomodar o logo
            ws.row_dimensions[2].height = 90  # Aumentada para o dobro da altura original
            
            # Carregar a imagem
            logo_img = Image(os.path.join("assets", "logo.png"))
            
            # Calcular o tamanho da célula D2:E2 com base nas dimensões das colunas
            # A coluna D tem 30 unidades e a coluna E tem 20 unidades de largura
            # Convertemos essas unidades em pixels para ajustar a imagem ao tamanho da célula
            largura_total_pixels = (ws.column_dimensions['D'].width + ws.column_dimensions['E'].width) * 7  # Aproximadamente 7 pixels por unidade de largura
            #altura_celula_pixels = ws.row_dimensions[2].height * 0.75  # Convertendo a altura da linha em pixels (aproximado)
            
            # Redimensionar a imagem para caber exatamente na célula
            logo_img.width = int(largura_total_pixels)
            logo_img.height = 130
            
            # Adicionar a imagem à planilha
            ws.add_image(logo_img, 'D2')
        
        # Tipo e Prazo de Entrega
        ws.merge_cells('A3:C3')
        ws['A3'] = tipo
        ws['A3'].font = cabecalho_font
        ws['A3'].alignment = center_align
        ws['A3'].border = medium_border
        
        ws.merge_cells('D3:E3')
        ws['D3'] = f"PRAZO DE ENTREGA FINAL: {prazo_entrega}"
        ws['D3'].font = cabecalho_font
        ws['D3'].alignment = center_align
        ws['D3'].border = medium_border
        
        # Informações básicas
        info_rows = [
            ("Cliente:", cliente),
            ("Equipamento:", maquina),
            ("Número de Série:", numero_serie),
            ("Nº de Patrimônio:", patrimonio),
            ("Data de abertura O.S.I.:", data),
            ("Local:", local)
        ]
        
        row = 4
        for label, valor in info_rows:
            ws.merge_cells(f'A{row}:E{row}')
            ws[f'A{row}'].font = normal_font
            ws[f'A{row}'].alignment = center_align
            ws[f'A{row}'].border = medium_border
            ws[f'A{row}'] = f"{label} {valor}"
            row += 1
        
        # Tabela de tarefas
        ws.merge_cells(f'A{row}:C{row}')
        ws[f'A{row}'] = "TAREFA A EXECUTAR"
        ws[f'A{row}'].font = cabecalho_font
        ws[f'A{row}'].alignment = center_align
        ws[f'A{row}'].border = medium_border
        
        ws[f'D{row}'] = "PRAZO PREVISTO"
        ws[f'D{row}'].font = cabecalho_font
        ws[f'D{row}'].alignment = center_align
        ws[f'D{row}'].border = medium_border
        
        ws[f'E{row}'] = "OK"
        ws[f'E{row}'].font = cabecalho_font
        ws[f'E{row}'].alignment = center_align
        ws[f'E{row}'].border = medium_border
        row += 1
        
        # Linhas para tarefas (vazias) conforme a imagem
        for _ in range(20):  # Aumentado para ter o mesmo número de linhas da imagem
            ws.merge_cells(f'A{row}:C{row}')
            ws[f'A{row}'].border = medium_border
            ws[f'D{row}'].border = medium_border
            ws[f'E{row}'].border = medium_border
            row += 1
        
        # Observações
        ws.merge_cells(f'A{row}:E{row}')
        ws[f'A{row}'] = "OBSERVAÇÕES:"
        ws[f'A{row}'].font = cabecalho_font
        ws[f'A{row}'].alignment = center_align
        ws[f'A{row}'].border = medium_border
        row += 1
        
        # Área de observações (5 linhas)
        for _ in range(5):
            ws.merge_cells(f'A{row}:E{row}')
            ws[f'A{row}'].border = medium_border
            ws.row_dimensions[row].height = 30  # Maior altura para área de observações
            row += 1
        
        # Definir a área de impressão (A1:E36)
        ws.print_area = 'A1:E36'
        
        # Configurações adicionais de impressão
        ws.page_setup.orientation = ws.ORIENTATION_PORTRAIT
        ws.page_setup.paperSize = ws.PAPERSIZE_A4
        ws.page_setup.fitToPage = True
        ws.page_setup.fitToHeight = 1
        ws.page_setup.fitToWidth = 1
        
        # Novo caminho para salvar os arquivos
        pasta_base = os.path.join("MORACA", "MORACA", "DOCUMENTOS", "OS", "ABERTAS", "2025")
        
        # Garantir que a pasta existe
        if not os.path.exists(pasta_base):
            os.makedirs(pasta_base)
        
        # Salvar arquivo Excel no novo local
        arquivo_excel_novo = os.path.join(pasta_base, f"{numero}.xlsx")
        wb.save(arquivo_excel_novo)
        
        # Manter o salvamento original para compatibilidade
        pasta_status = {"Pendente": "Pendentes", "Em Andamento": "Em_Andamento", "Concluída": "Concluidas"}.get(status, "Pendentes")
        pasta_os = os.path.join("OSs", pasta_status, numero)
        if not os.path.exists(pasta_os):
            os.makedirs(pasta_os)
        
        arquivo_excel = os.path.join(pasta_os, f"{numero}.xlsx")
        wb.save(arquivo_excel)
    
    def gerar_arquivo_os(self, numero, cliente, maquina, descricao, urgencia, data, status, tipo,
                        patrimonio, numero_serie, local, endereco, telefone, cep,
                        contato_nome, contato_telefone1, contato_telefone2, descricao_servico,
                        necessita_viagem, tipo_hospedagem, prazo_entrega, empresa):
        # Criar documento
        doc = Document()
        
        # Configurações de página
        section = doc.sections[0]
        section.page_width = Inches(8.5)
        section.page_height = Inches(11)
        section.left_margin = Inches(0.5)
        section.right_margin = Inches(0.5)
        section.top_margin = Inches(0.5)
        section.bottom_margin = Inches(0.5)
        
        # Adicionar cabeçalho com timbre
        self.adicionar_cabecalho(doc, numero)
        
        # Adicionar título principal em formato similar ao Excel
        title_table = doc.add_table(rows=1, cols=1)
        title_cell = title_table.cell(0, 0)
        title_cell.text = f"O.S.I. - {numero} ({empresa})"
        title_paragraph = title_cell.paragraphs[0]
        title_paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        title_run = title_paragraph.runs[0]
        title_run.font.bold = True
        title_run.font.size = Pt(16)
        
        # Adicionar prazo de entrega
        prazo_table = doc.add_table(rows=1, cols=2)
        prazo_table.style = 'Table Grid'
        
        num_cell = prazo_table.cell(0, 0)
        num_cell.text = tipo
        num_cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        num_cell.paragraphs[0].runs[0].font.bold = True
        
        prazo_cell = prazo_table.cell(0, 1)
        prazo_cell.text = f"PRAZO DE ENTREGA FINAL: {prazo_entrega}"
        prazo_cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        prazo_cell.paragraphs[0].runs[0].font.bold = True
        
        # Adicionar informações básicas
        info_table = doc.add_table(rows=6, cols=1)
        info_table.style = 'Table Grid'
        
        # Cliente
        client_cell = info_table.cell(0, 0)
        client_paragraph = client_cell.paragraphs[0]
        client_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        client_run = client_paragraph.add_run("Cliente: ")
        client_run.font.bold = True
        client_paragraph.add_run(cliente)
        
        # Equipamento
        equip_cell = info_table.cell(1, 0)
        equip_paragraph = equip_cell.paragraphs[0]
        equip_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        equip_run = equip_paragraph.add_run("Equipamento: ")
        equip_run.font.bold = True
        equip_paragraph.add_run(maquina)
        
        # Número de Série
        serie_cell = info_table.cell(2, 0)
        serie_paragraph = serie_cell.paragraphs[0]
        serie_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        serie_run = serie_paragraph.add_run("Número de Série: ")
        serie_run.font.bold = True
        serie_paragraph.add_run(numero_serie)
        
        # Número de Patrimônio 
        patrim_cell = info_table.cell(3, 0)
        patrim_paragraph = patrim_cell.paragraphs[0]
        patrim_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        patrim_run = patrim_paragraph.add_run("Nº de Patrimônio: ")
        patrim_run.font.bold = True
        patrim_paragraph.add_run(patrimonio)
        
        # Data de abertura
        data_cell = info_table.cell(4, 0)
        data_paragraph = data_cell.paragraphs[0]
        data_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        data_run = data_paragraph.add_run("Data de abertura O.S.I.: ")
        data_run.font.bold = True
        data_paragraph.add_run(data)
        
        # Local
        local_cell = info_table.cell(5, 0)
        local_paragraph = local_cell.paragraphs[0]
        local_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        local_run = local_paragraph.add_run("Local: ")
        local_run.font.bold = True
        local_paragraph.add_run(local)
        
        # Adicionar tabela de tarefas
        doc.add_paragraph().add_run().add_break()
        tarefas_table = doc.add_table(rows=11, cols=3)
        tarefas_table.style = 'Table Grid'
        
        # Cabeçalho da tabela
        header_cells = tarefas_table.rows[0].cells
        header_cells[0].text = "TAREFA A EXECUTAR"
        header_cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        header_cells[0].paragraphs[0].runs[0].font.bold = True
        
        header_cells[1].text = "PRAZO PREVISTO"
        header_cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        header_cells[1].paragraphs[0].runs[0].font.bold = True
        
        header_cells[2].text = "OK"
        header_cells[2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        header_cells[2].paragraphs[0].runs[0].font.bold = True
        
        # Na primeira linha, colocar a descrição do problema
        task_cells = tarefas_table.rows[1].cells
        task_cells[0].text = "Problema: " + descricao.strip()
        
        # Na segunda linha, colocar a descrição do serviço
        service_cells = tarefas_table.rows[2].cells
        service_cells[0].text = "Serviço: " + descricao_servico.strip()
        
        # Adicionar seção de observações
        doc.add_paragraph().add_run().add_break()
        obs_table = doc.add_table(rows=2, cols=1)
        obs_table.style = 'Table Grid'
        
        # Cabeçalho de observações
        obs_header = obs_table.rows[0].cells[0]
        obs_header.text = "OBSERVAÇÕES:"
        obs_header.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        obs_header.paragraphs[0].runs[0].font.bold = True
        
        # Espaço para observações (célula vazia)
        obs_cell = obs_table.rows[1].cells[0]
        obs_paragraph = obs_cell.paragraphs[0]
        obs_paragraph.add_run(" ")
        # Definir altura da célula
        obs_table.rows[1].height = Inches(2)
        
        # Informações adicionais
        doc.add_paragraph().add_run().add_break()
        info_adicional = doc.add_paragraph()
        info_adicional.add_run("Informações Adicionais:").bold = True
        info_adicional.add_run().add_break()
        
        info_adicional.add_run("Endereço: ").bold = True
        info_adicional.add_run(f"{endereco}\n")
        
        info_adicional.add_run("CEP: ").bold = True
        info_adicional.add_run(f"{cep}\n")
        
        info_adicional.add_run("Telefone: ").bold = True
        info_adicional.add_run(f"{telefone}\n")
        
        info_adicional.add_run("Contato: ").bold = True
        info_adicional.add_run(f"{contato_nome}\n")
        
        info_adicional.add_run("Telefone do Contato 1: ").bold = True
        info_adicional.add_run(f"{contato_telefone1}\n")
        
        if contato_telefone2:
            info_adicional.add_run("Telefone do Contato 2: ").bold = True
            info_adicional.add_run(f"{contato_telefone2}\n")
        
        info_adicional.add_run("Urgência: ").bold = True
        info_adicional.add_run(f"{urgencia}\n")
        
        info_adicional.add_run("Status: ").bold = True
        info_adicional.add_run(f"{status}\n")
        
        # Informações sobre viagem e hospedagem
        info_adicional.add_run().add_break()
        info_adicional.add_run("Informações de Logística:").bold = True
        info_adicional.add_run().add_break()
        
        info_adicional.add_run("Necessita de Viagem: ").bold = True
        info_adicional.add_run(f"{necessita_viagem}\n")
        
        info_adicional.add_run("Tipo de Hospedagem: ").bold = True
        info_adicional.add_run(f"{tipo_hospedagem}\n")
        
        info_adicional.add_run("Prazo de Entrega: ").bold = True
        info_adicional.add_run(f"{prazo_entrega}\n")
        
        # Determinar pasta baseado no status
        pasta_status = {
            "Pendente": "Pendentes",
            "Em Andamento": "Em_Andamento",
            "Concluída": "Concluidas"
        }.get(status, "Pendentes")
        
        # Criar pasta específica para a OS
        pasta_os = os.path.join("OSs", pasta_status, numero)
        if not os.path.exists(pasta_os):
            os.makedirs(pasta_os)
        
        # Salvar arquivo
        arquivo = os.path.join(pasta_os, f"{numero}.docx")
        doc.save(arquivo)
        
        # Criar arquivo interno (similar, mas com mais detalhes)
        doc_interno = Document()
        
        # Configurações de página para documento interno
        section = doc_interno.sections[0]
        section.page_width = Inches(8.5)
        section.page_height = Inches(11)
        section.left_margin = Inches(0.5)
        section.right_margin = Inches(0.5)
        section.top_margin = Inches(0.5)
        section.bottom_margin = Inches(0.5)
        
        # Adicionar cabeçalho com timbre no documento interno
        self.adicionar_cabecalho(doc_interno, f"{numero} - INTERNO")
        
        # Adicionar título principal
        title_table = doc_interno.add_table(rows=1, cols=1)
        title_cell = title_table.cell(0, 0)
        title_cell.text = f"O.S.I. INTERNO - {numero} ({empresa})"
        title_paragraph = title_cell.paragraphs[0]
        title_paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        title_run = title_paragraph.runs[0]
        title_run.font.bold = True
        title_run.font.size = Pt(16)
        
        # Adicionar prazo de entrega
        prazo_table = doc_interno.add_table(rows=1, cols=2)
        prazo_table.style = 'Table Grid'
        
        num_cell = prazo_table.cell(0, 0)
        num_cell.text = tipo
        num_cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        num_cell.paragraphs[0].runs[0].font.bold = True
        
        prazo_cell = prazo_table.cell(0, 1)
        prazo_cell.text = f"PRAZO DE ENTREGA FINAL: {prazo_entrega}"
        prazo_cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        prazo_cell.paragraphs[0].runs[0].font.bold = True
        
        # Adicionar todas as informações no documento interno
        info_completa = doc_interno.add_paragraph()
        info_completa.add_run("INFORMAÇÕES COMPLETAS:").bold = True
        info_completa.add_run().add_break()
        
        info_completa.add_run("Empresa: ").bold = True
        info_completa.add_run(f"{empresa}\n")
        
        info_completa.add_run("Cliente: ").bold = True
        info_completa.add_run(f"{cliente}\n")
        
        info_completa.add_run("Máquina: ").bold = True
        info_completa.add_run(f"{maquina}\n")
        
        info_completa.add_run("Tipo: ").bold = True
        info_completa.add_run(f"{tipo}\n")
        
        info_completa.add_run("Nº de Patrimônio: ").bold = True
        info_completa.add_run(f"{patrimonio}\n")
        
        info_completa.add_run("Nº de Série: ").bold = True
        info_completa.add_run(f"{numero_serie}\n")
        
        info_completa.add_run("Local: ").bold = True
        info_completa.add_run(f"{local}\n")
        
        info_completa.add_run("Endereço: ").bold = True
        info_completa.add_run(f"{endereco}\n")
        
        info_completa.add_run("Telefone: ").bold = True
        info_completa.add_run(f"{telefone}\n")
        
        info_completa.add_run("CEP: ").bold = True
        info_completa.add_run(f"{cep}\n")
        
        info_completa.add_run("Contato no Local: ").bold = True
        info_completa.add_run(f"{contato_nome}\n")
        
        info_completa.add_run("Telefone do Contato 1: ").bold = True
        info_completa.add_run(f"{contato_telefone1}\n")
        
        if contato_telefone2:
            info_completa.add_run("Telefone do Contato 2: ").bold = True
            info_completa.add_run(f"{contato_telefone2}\n")
        
        info_completa.add_run("Urgência: ").bold = True
        info_completa.add_run(f"{urgencia}\n")
        
        info_completa.add_run("Status: ").bold = True
        info_completa.add_run(f"{status}\n")
        
        # Informações sobre viagem e hospedagem
        info_completa.add_run().add_break()
        info_completa.add_run("INFORMAÇÕES DE LOGÍSTICA:").bold = True
        info_completa.add_run().add_break()
        
        info_completa.add_run("Necessita de Viagem: ").bold = True
        info_completa.add_run(f"{necessita_viagem}\n")
        
        info_completa.add_run("Tipo de Hospedagem: ").bold = True
        info_completa.add_run(f"{tipo_hospedagem}\n")
        
        info_completa.add_run("Prazo de Entrega: ").bold = True
        info_completa.add_run(f"{prazo_entrega}\n")
        
        # Adicionar descrições no documento interno
        descricao_problema = doc_interno.add_paragraph()
        descricao_problema.add_run("Descrição do Problema:").bold = True
        descricao_problema.add_run().add_break()
        descricao_problema.add_run(descricao)
        
        descricao_problema.add_run().add_break()
        descricao_problema.add_run().add_break()
        
        descricao_servico_p = doc_interno.add_paragraph()
        descricao_servico_p.add_run("Descrição do Serviço Solicitado:").bold = True
        descricao_servico_p.add_run().add_break()
        descricao_servico_p.add_run(descricao_servico)
        
        # Adicionar tabela de tarefas internas
        doc_interno.add_paragraph().add_run().add_break()
        tarefas_table = doc_interno.add_table(rows=11, cols=3)
        tarefas_table.style = 'Table Grid'
        
        # Cabeçalho da tabela
        header_cells = tarefas_table.rows[0].cells
        header_cells[0].text = "TAREFA A EXECUTAR (INTERNO)"
        header_cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        header_cells[0].paragraphs[0].runs[0].font.bold = True
        
        header_cells[1].text = "PRAZO PREVISTO"
        header_cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        header_cells[1].paragraphs[0].runs[0].font.bold = True
        
        header_cells[2].text = "OK"
        header_cells[2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        header_cells[2].paragraphs[0].runs[0].font.bold = True
        
        # Adicionar seção de observações internas
        doc_interno.add_paragraph().add_run().add_break()
        obs_table = doc_interno.add_table(rows=2, cols=1)
        obs_table.style = 'Table Grid'
        
        # Cabeçalho de observações
        obs_header = obs_table.rows[0].cells[0]
        obs_header.text = "OBSERVAÇÕES INTERNAS:"
        obs_header.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        obs_header.paragraphs[0].runs[0].font.bold = True
        
        # Espaço para observações (célula vazia)
        obs_cell = obs_table.rows[1].cells[0]
        obs_paragraph = obs_cell.paragraphs[0]
        obs_paragraph.add_run(" ")
        # Definir altura da célula
        obs_table.rows[1].height = Inches(2)
        
        arquivo_interno = os.path.join(pasta_os, f"{numero}_INTERNA.docx")
        doc_interno.save(arquivo_interno)
    
    def criar_nova_os(self):
        # Criar nova janela
        nova_janela = ttk.Toplevel(self.root)
        nova_janela.title("Nova Ordem de Serviço")
        nova_janela.geometry("700x850")
        
        # Container principal
        main_container = ttk.Frame(nova_janela)
        main_container.pack(fill=BOTH, expand=TRUE)
        
        # Canvas para permitir scrolling
        canvas = ttk.Canvas(main_container)
        canvas.pack(side=LEFT, fill=BOTH, expand=TRUE)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(main_container, orient=VERTICAL, command=canvas.yview)
        scrollbar.pack(side=RIGHT, fill=Y)
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Frame interior para os elementos do formulário
        form_frame = ttk.Frame(canvas)
        
        # Criar janela dentro do canvas
        window_id = canvas.create_window((0, 0), window=form_frame, anchor=NW, width=680)
        
        # Função para atualizar scrollregion
        def _configure_frame(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
        
        # Função para ajustar largura da janela interna
        def _configure_canvas(event):
            canvas.itemconfig(window_id, width=event.width)
        
        # Função de scroll multiplataforma
        def _on_mousewheel(event):
            # Linux: evento Button-4 (rolar para cima) e Button-5 (rolar para baixo)
            if event.num == 4:
                canvas.yview_scroll(-1, "units")
            elif event.num == 5:
                canvas.yview_scroll(1, "units")
            # Windows: evento MouseWheel com delta
            elif hasattr(event, 'delta'):
                canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        # Vincular eventos multiplataforma
        form_frame.bind("<Configure>", _configure_frame)
        canvas.bind("<Configure>", _configure_canvas)
        
        # Vincular eventos de scroll específicos por plataforma
        # Windows/macOS
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        # Linux
        canvas.bind_all("<Button-4>", _on_mousewheel)
        canvas.bind_all("<Button-5>", _on_mousewheel)
    
        # Organizando o formulário em seções
        current_row = 0
        
        # SEÇÃO DE SELEÇÃO DE EMPRESA (NOVA)
        ttk.Label(form_frame, text="SELEÇÃO DE EMPRESA", font=("Helvetica", 12, "bold")).grid(row=current_row, column=0, columnspan=2, sticky=W, padx=10, pady=(20,5))
        current_row += 1
        ttk.Separator(form_frame, orient=HORIZONTAL).grid(row=current_row, column=0, columnspan=2, sticky=EW, padx=10, pady=5)
        current_row += 1
        
        # Campo de Seleção de Empresa
        ttk.Label(form_frame, text="Empresa:", font=("Helvetica", 11, "bold")).grid(row=current_row, column=0, sticky=W, padx=10, pady=10)
        empresa_var = ttk.StringVar(value="")
        empresa_frame = ttk.Frame(form_frame)
        empresa_frame.grid(row=current_row, column=1, sticky=W, padx=10, pady=10)
        
        ttk.Radiobutton(empresa_frame, text="MORACA", value="MORACA", variable=empresa_var).pack(side=LEFT, padx=10)
        ttk.Radiobutton(empresa_frame, text="ZIEHM", value="ZIEHM", variable=empresa_var).pack(side=LEFT, padx=10)
        ttk.Radiobutton(empresa_frame, text="MORACA/ZIEHM", value="MORACA/ZIEHM", variable=empresa_var).pack(side=LEFT, padx=10)
        
        # Informações sobre campo obrigatório
        ttk.Label(form_frame, text="* Campo obrigatório", font=("Helvetica", 8), foreground="red").grid(row=current_row+1, column=1, sticky=W, padx=10)
        current_row += 2
        
        # SEÇÃO 1: INFORMAÇÕES BÁSICAS
        ttk.Label(form_frame, text="INFORMAÇÕES BÁSICAS", font=("Helvetica", 12, "bold")).grid(row=current_row, column=0, columnspan=2, sticky=W, padx=10, pady=(20,5))
        current_row += 1
        ttk.Separator(form_frame, orient=HORIZONTAL).grid(row=current_row, column=0, columnspan=2, sticky=EW, padx=10, pady=5)
        current_row += 1
        
        # Tipo de OS
        ttk.Label(form_frame, text="Tipo de OS:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        tipo_var = ttk.StringVar(value="MANUTENÇÃO CORRETIVA")
        tipo_combo = ttk.Combobox(
            form_frame,
            textvariable=tipo_var,
            values=["MANUTENÇÃO CORRETIVA", "MANUTENÇÃO PREVENTIVA", "ENTRADA DE MÁQUINA"],
            state="readonly",
            width=40
        )
        tipo_combo.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Data - Usar Entry simples com formato em vez de DateEntry
        ttk.Label(form_frame, text="Data:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        data_var = ttk.StringVar(value=datetime.now().strftime("%d/%m/%Y"))
        data_entry = ttk.Entry(
            form_frame,
            textvariable=data_var,
            width=20
        )
        data_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Cliente
        ttk.Label(form_frame, text="Nome do Cliente:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        cliente_entry = ttk.Entry(form_frame, width=40)
        cliente_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Máquina
        ttk.Label(form_frame, text="Tipo de Máquina:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        maquina_entry = ttk.Entry(form_frame, width=40)
        maquina_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Patrimônio
        ttk.Label(form_frame, text="Nº de Patrimônio:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        patrimonio_entry = ttk.Entry(form_frame, width=40)
        patrimonio_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Número de Série
        ttk.Label(form_frame, text="Nº de Série:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        numero_serie_entry = ttk.Entry(form_frame, width=40)
        numero_serie_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # SEÇÃO 2: LOCALIZAÇÃO
        ttk.Label(form_frame, text="LOCALIZAÇÃO", font=("Helvetica", 12, "bold")).grid(row=current_row, column=0, columnspan=2, sticky=W, padx=10, pady=(20,5))
        current_row += 1
        ttk.Separator(form_frame, orient=HORIZONTAL).grid(row=current_row, column=0, columnspan=2, sticky=EW, padx=10, pady=5)
        current_row += 1
        
        # Local
        ttk.Label(form_frame, text="Local:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        local_entry = ttk.Entry(form_frame, width=40)
        local_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Endereço
        ttk.Label(form_frame, text="Endereço:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        endereco_entry = ttk.Entry(form_frame, width=40)
        endereco_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Telefone
        ttk.Label(form_frame, text="Telefone:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        telefone_entry = ttk.Entry(form_frame, width=40)
        telefone_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # CEP
        ttk.Label(form_frame, text="CEP:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        cep_entry = ttk.Entry(form_frame, width=40)
        cep_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # SEÇÃO 3: CONTATO
        ttk.Label(form_frame, text="INFORMAÇÕES DE CONTATO", font=("Helvetica", 12, "bold")).grid(row=current_row, column=0, columnspan=2, sticky=W, padx=10, pady=(20,5))
        current_row += 1
        ttk.Separator(form_frame, orient=HORIZONTAL).grid(row=current_row, column=0, columnspan=2, sticky=EW, padx=10, pady=5)
        current_row += 1
        
        # Nome do Contato
        ttk.Label(form_frame, text="Nome do Contato:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        contato_nome_entry = ttk.Entry(form_frame, width=40)
        contato_nome_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Telefone do Contato 1
        ttk.Label(form_frame, text="Telefone do Contato 1:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        contato_telefone1_entry = ttk.Entry(form_frame, width=40)
        contato_telefone1_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Telefone do Contato 2
        ttk.Label(form_frame, text="Telefone do Contato 2:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        contato_telefone2_entry = ttk.Entry(form_frame, width=40)
        contato_telefone2_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # SEÇÃO 4: LOGÍSTICA
        ttk.Label(form_frame, text="LOGÍSTICA E PRAZOS", font=("Helvetica", 12, "bold")).grid(row=current_row, column=0, columnspan=2, sticky=W, padx=10, pady=(20,5))
        current_row += 1
        ttk.Separator(form_frame, orient=HORIZONTAL).grid(row=current_row, column=0, columnspan=2, sticky=EW, padx=10, pady=5)
        current_row += 1
        
        # Prazo - Remover DateEntry e usar apenas o Entry
        ttk.Label(form_frame, text="Prazo de Entrega:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        prazo_var = ttk.StringVar(value=(datetime.now() + timedelta(days=7)).strftime("%d/%m/%Y"))
        prazo_entry = ttk.Entry(
            form_frame,
            textvariable=prazo_var,
            width=20
        )
        prazo_entry.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Viagem
        ttk.Label(form_frame, text="Necessita de Viagem?").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        viagem_var = ttk.StringVar(value="Não")
        viagem_frame = ttk.Frame(form_frame)
        viagem_frame.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        ttk.Radiobutton(viagem_frame, text="Sim", value="Sim", variable=viagem_var).pack(side=LEFT, padx=5)
        ttk.Radiobutton(viagem_frame, text="Não", value="Não", variable=viagem_var).pack(side=LEFT, padx=5)
        current_row += 1
        
        # Hospedagem
        ttk.Label(form_frame, text="Tipo de Hospedagem:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        hospedagem_var = ttk.StringVar(value="Não necessário")
        hospedagem_combo = ttk.Combobox(
            form_frame,
            textvariable=hospedagem_var,
            values=["Não necessário", "Hotel", "Airbnb", "Outro"],
            state="readonly",
            width=40
        )
        hospedagem_combo.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # SEÇÃO 5: DESCRIÇÕES
        ttk.Label(form_frame, text="DESCRIÇÕES", font=("Helvetica", 12, "bold")).grid(row=current_row, column=0, columnspan=2, sticky=W, padx=10, pady=(20,5))
        current_row += 1
        ttk.Separator(form_frame, orient=HORIZONTAL).grid(row=current_row, column=0, columnspan=2, sticky=EW, padx=10, pady=5)
        current_row += 1
        
        # Descrição do Problema
        ttk.Label(form_frame, text="Descrição do Problema:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        current_row += 1
        descricao_text = ttk.Text(form_frame, width=60, height=5)
        descricao_text.grid(row=current_row, column=0, columnspan=2, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Descrição do Serviço
        ttk.Label(form_frame, text="Descrição do Serviço:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        current_row += 1
        descricao_servico_text = ttk.Text(form_frame, width=60, height=5)
        descricao_servico_text.grid(row=current_row, column=0, columnspan=2, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Urgência
        ttk.Label(form_frame, text="Nível de Urgência:").grid(row=current_row, column=0, sticky=W, padx=10, pady=5)
        urgencia_var = ttk.StringVar(value="Normal")
        urgencia_combo = ttk.Combobox(
            form_frame,
            textvariable=urgencia_var,
            values=["Normal", "Alta", "Crítica"],
            state="readonly",
            width=40
        )
        urgencia_combo.grid(row=current_row, column=1, sticky=W, padx=10, pady=5)
        current_row += 1
        
        # Botões
        button_frame = ttk.Frame(form_frame)
        button_frame.grid(row=current_row, column=0, columnspan=2, pady=20)
        
        def salvar_os():
            # Validar campos obrigatórios
            if not empresa_var.get().strip():
                messagebox.showerror("Erro", "Selecionar a empresa é obrigatório!")
                return
            if not cliente_entry.get().strip():
                messagebox.showerror("Erro", "Nome do cliente é obrigatório!")
                return
            if not maquina_entry.get().strip():
                messagebox.showerror("Erro", "Tipo de máquina é obrigatório!")
                return
            if not descricao_text.get("1.0", END).strip():
                messagebox.showerror("Erro", "Descrição do problema é obrigatória!")
                return
            
            # Gerar número da OS
            ano = datetime.now().strftime("%y")
            conn = sqlite3.connect('moraca.db')
            c = conn.cursor()
            c.execute("SELECT COUNT(*) FROM os")
            count = c.fetchone()[0]
            numero = f"OS{ano}{str(count + 1).zfill(3)}"
            
            # Preparar dados
            cliente = cliente_entry.get()
            maquina = maquina_entry.get()
            descricao = descricao_text.get("1.0", END)
            urgencia = urgencia_var.get()
            tipo = tipo_var.get()
            data = data_var.get()
            status = "Pendente"
            
            # Novos campos
            patrimonio = patrimonio_entry.get()
            numero_serie = numero_serie_entry.get()
            local = local_entry.get()
            endereco = endereco_entry.get()
            telefone = telefone_entry.get()
            cep = cep_entry.get()
            contato_nome = contato_nome_entry.get()
            contato_telefone1 = contato_telefone1_entry.get()
            contato_telefone2 = contato_telefone2_entry.get()
            descricao_servico = descricao_servico_text.get("1.0", END)
            
            # Campos adicionais
            necessita_viagem = viagem_var.get()
            tipo_hospedagem = hospedagem_var.get()
            prazo_entrega = prazo_var.get()
            empresa = empresa_var.get()
            
            # Inserir no banco
            c.execute('''INSERT INTO os VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                     (numero, cliente, maquina, descricao, urgencia, data, status, tipo,
                      patrimonio, numero_serie, local, endereco, telefone, cep,
                      contato_nome, contato_telefone1, contato_telefone2, descricao_servico,
                      necessita_viagem, tipo_hospedagem, prazo_entrega, empresa))
            conn.commit()
            conn.close()
            
            # Criar dicionário com os dados do cliente para o modelo Ziehm
            dados_cliente = {
                'cliente': cliente,
                'equipamento': maquina,
                'modelo': maquina,
                'numero_serie': numero_serie,
                'patrimonio': patrimonio,
                'endereco': endereco,
                'contato': contato_nome,
                'telefone': telefone,
                'telefone1': contato_telefone1,
                'telefone2': contato_telefone2,
                'local': local,
                'cep': cep,
                'descricao': descricao,
                'descricao_servico': descricao_servico,
                'urgencia': urgencia,
                'tipo': tipo,
                'data': data,
                'prazo_entrega': prazo_entrega,
                'necessita_viagem': necessita_viagem,
                'tipo_hospedagem': tipo_hospedagem,
                'status': status
            }
            
            # Gerar arquivos Excel - Verificar qual modelo usar
            if empresa == "ZIEHM":
                # Usar o modelo da Ziehm
                criar_os_ziehm(numero, dados_cliente)
            else:
                # Usar o modelo padrão da Moraca
                self.gerar_arquivo_excel_os(numero, cliente, maquina, descricao, urgencia, data, status, tipo,
                                    patrimonio, numero_serie, local, endereco, telefone, cep,
                                    contato_nome, contato_telefone1, contato_telefone2, descricao_servico,
                                    necessita_viagem, tipo_hospedagem, prazo_entrega, empresa)

            # Gerar arquivos Word (sempre usa o mesmo modelo)
            self.gerar_arquivo_os(numero, cliente, maquina, descricao, urgencia, data, status, tipo,
                                patrimonio, numero_serie, local, endereco, telefone, cep,
                                contato_nome, contato_telefone1, contato_telefone2, descricao_servico,
                                necessita_viagem, tipo_hospedagem, prazo_entrega, empresa)
            
            # Mostrar mensagem de sucesso
            messagebox.showinfo("Sucesso", f"OS {numero} criada com sucesso!")
            
            self.atualizar_lista()
            nova_janela.destroy()
        
        # Botões
        ttk.Button(
            button_frame,
            text="Criar OS",
            command=salvar_os,
            style="primary.TButton",
            width=15
        ).pack(side=LEFT, padx=5)
    
        ttk.Button(
            button_frame,
            text="Cancelar",
            command=nova_janela.destroy,
            style="secondary.TButton",
            width=15
        ).pack(side=LEFT, padx=5)
        
        # Atualizar a região de scroll no final
        form_frame.update_idletasks()
        canvas.configure(scrollregion=canvas.bbox("all"))
        
        # Garantir que a rolagem funciona
        canvas.bind_all("<MouseWheel>", lambda event: canvas.yview_scroll(int(-1*(event.delta/120)), "units"))
    
    def buscar_os(self):
        termo = self.search_entry.get()
        # Limpar tabela
        for item in self.tabela.get_children():
            self.tabela.delete(item)
        
        # Buscar no banco
        conn = sqlite3.connect('moraca.db')
        c = conn.cursor()
        c.execute('''SELECT numero, cliente, data, status FROM os
                    WHERE numero LIKE ? OR cliente LIKE ?
                    ORDER BY data DESC''', (f"%{termo}%", f"%{termo}%"))
        
        for row in c.fetchall():
            self.tabela.insert("", END, values=row)
        
        conn.close()
    
    def atualizar_lista(self):
        # Limpar tabela
        for item in self.tabela.get_children():
            self.tabela.delete(item)
        
        # Buscar últimas OS
        conn = sqlite3.connect('moraca.db')
        c = conn.cursor()
        c.execute('''SELECT numero, cliente, data, status FROM os
                    ORDER BY data DESC LIMIT 10''')
        
        for row in c.fetchall():
            self.tabela.insert("", END, values=row)
        
        conn.close()

    def adicionar_cabecalho(self, doc, numero_os):
        """Adiciona o cabeçalho com o timbre da empresa no documento"""
        # Adicionar tabela para o cabeçalho
        table = doc.add_table(rows=1, cols=2)
        table.autofit = False
        table.allow_autofit = False
        
        # Células da tabela
        cell_os = table.cell(0, 0)
        cell_logo = table.cell(0, 1)
        
        # Configurar larguras
        cell_os.width = Inches(2.5)
        cell_logo.width = Inches(4.0)
        
        # Adicionar número da OS
        os_paragraph = cell_os.paragraphs[0]
        os_paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        os_run = os_paragraph.add_run()
        os_run.add_text("Ordem de Serviço\n")
        os_run.font.size = Pt(12)
        os_run.font.bold = True
        os_run.add_text(f"{numero_os}")
        os_run.font.size = Pt(14)
        os_run.font.bold = True
        
        # Adicionar logo
        logo_paragraph = cell_logo.paragraphs[0]
        logo_paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        logo_run = logo_paragraph.add_run()
        logo_path = os.path.join("assets", "logo.png")
        if os.path.exists(logo_path):
            logo_run.add_picture(logo_path, width=Inches(3.5))
        
        # Adicionar espaço após o cabeçalho
        doc.add_paragraph()

    def gerar_os_interna_andamento(self):
        # Criar uma janela para solicitar o número da OS
        janela = ttk.Toplevel(self.root)
        janela.title("Gerar OS Interna de Andamento")
        janela.geometry("400x200")
        
        # Frame principal
        frame = ttk.Frame(janela, padding=20)
        frame.pack(fill=BOTH, expand=YES)
        
        # Título
        ttk.Label(
            frame,
            text="Gerar OS Interna de Andamento",
            font=("Helvetica", 12, "bold")
        ).pack(pady=(0, 20))
        
        # Frame para entrada
        input_frame = ttk.Frame(frame)
        input_frame.pack(pady=10)
        
        # Campo para número da OS
        ttk.Label(input_frame, text="Número da OS:").grid(row=0, column=0, padx=5, pady=5, sticky=W)
        numero_os_entry = ttk.Entry(input_frame, width=20)
        numero_os_entry.grid(row=0, column=1, padx=5, pady=5, sticky=W)
        
        # Adicionar instruções sobre o formato
        ttk.Label(input_frame, text="Formato: ano + número (ex: 25019)", foreground="gray").grid(row=1, column=0, columnspan=2, padx=5, pady=0, sticky=W)
        
        # Função para gerar o documento
        def gerar_documento():
            numero_os = numero_os_entry.get().strip()
            
            if not numero_os:
                messagebox.showerror("Erro", "Por favor, informe o número da OS.")
                return
            
            try:
                # Caminho para salvar o documento
                pasta_destino = os.path.join("/home/gabriel-balsarin/Projetos/Moraca/MORACA", "MORACA1", "DOCUMENTOS", "tecnico", "andamento")
                
                # Verificar se o módulo está disponível
                if 'criar_os_interna_andamento' in globals():
                    # Gerar o documento
                    caminho_arquivo = criar_os_interna_andamento(numero_os, pasta_destino)
                    
                    messagebox.showinfo("Sucesso", f"Documento gerado com sucesso em:\n{caminho_arquivo}")
                    janela.destroy()
                else:
                    messagebox.showerror("Erro", "Funcionalidade não disponível. O módulo os_interna_andamento não está acessível.")
            except Exception as e:
                messagebox.showerror("Erro", f"Ocorreu um erro ao gerar o documento:\n{str(e)}")
        
        # Frame para botões
        button_frame = ttk.Frame(frame)
        button_frame.pack(pady=20)
        
        # Botões
        ttk.Button(
            button_frame,
            text="Gerar",
            command=gerar_documento,
            style="primary.TButton",
            width=15
        ).pack(side=LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Cancelar",
            command=janela.destroy,
            style="secondary.TButton",
            width=15
        ).pack(side=LEFT, padx=5)

if __name__ == "__main__":
    app = MoracaOS()
    app.root.mainloop() 