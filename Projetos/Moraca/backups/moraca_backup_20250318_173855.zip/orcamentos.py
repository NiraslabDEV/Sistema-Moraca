import os
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side
from datetime import datetime, timedelta

class GerenciadorOrcamentos:
    """
    Classe para gerenciar orçamentos do sistema Moraca.
    Permite criar, editar, consultar e aprovar orçamentos.
    """
    
    def __init__(self):
        """Inicializa o gerenciador de orçamentos."""
        self.base_path = os.path.join("MORACA", "MORACA1", "DOCUMENTOS", "orcamentos")
        self._inicializar_estrutura()
        
    def _inicializar_estrutura(self):
        """Inicializa a estrutura de pastas necessária para os orçamentos."""
        if not os.path.exists(self.base_path):
            os.makedirs(self.base_path)
            print(f"Pasta de orçamentos criada em: {self.base_path}")
            
        # Subpastas para diferentes status
        for pasta in ["pendentes", "aprovados", "rejeitados", "convertidos"]:
            pasta_path = os.path.join(self.base_path, pasta)
            if not os.path.exists(pasta_path):
                os.makedirs(pasta_path)
                
        # Criar arquivo de controle se não existir
        self.controle_file = os.path.join(self.base_path, "controle_orcamentos.xlsx")
        if not os.path.exists(self.controle_file):
            self._criar_arquivo_controle()
            
    def _criar_arquivo_controle(self):
        """Cria o arquivo Excel para controle de orçamentos."""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Controle de Orçamentos"
        
        # Definir cabeçalhos
        headers = ["Número", "Cliente", "Equipamento", "Data Criação", 
                   "Validade", "Valor Total", "Status", "Aprovado Por", 
                   "Data Aprovação", "Convertido em OS"]
        
        for col, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col)
            cell.value = header
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal='center')
            
        # Configurar larguras das colunas
        ws.column_dimensions['A'].width = 12  # Número
        ws.column_dimensions['B'].width = 30  # Cliente
        ws.column_dimensions['C'].width = 25  # Equipamento
        ws.column_dimensions['D'].width = 15  # Data Criação
        ws.column_dimensions['E'].width = 15  # Validade
        ws.column_dimensions['F'].width = 15  # Valor Total
        ws.column_dimensions['G'].width = 15  # Status
        ws.column_dimensions['H'].width = 20  # Aprovado Por
        ws.column_dimensions['I'].width = 15  # Data Aprovação
        ws.column_dimensions['J'].width = 15  # Convertido em OS
        
        # Salvar arquivo
        wb.save(self.controle_file)
        print(f"Arquivo de controle de orçamentos criado em: {self.controle_file}")
    
    def gerar_numero_orcamento(self):
        """
        Gera um número sequencial para o novo orçamento.
        
        Returns:
            str: Número do orçamento no formato 'ORC-AAAAMMDD-XXX'
        """
        try:
            wb = openpyxl.load_workbook(self.controle_file)
            ws = wb.active
            
            # Contar número de orçamentos existentes (excluindo cabeçalho)
            num_orcamentos = ws.max_row - 1
            
            # Gerar número no formato ORC-AAAAMMDD-XXX
            data_atual = datetime.now().strftime("%Y%m%d")
            numero = f"ORC-{data_atual}-{num_orcamentos + 1:03d}"
            
            return numero
            
        except Exception as e:
            print(f"Erro ao gerar número de orçamento: {e}")
            # Fallback em caso de erro
            return f"ORC-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    
    def criar_orcamento(self, cliente, equipamento, contato=None, items=None, observacoes=None):
        """
        Cria um novo orçamento básico.
        
        Args:
            cliente (str): Nome do cliente
            equipamento (str): Descrição do equipamento
            contato (str, optional): Informações de contato
            items (list, optional): Lista de itens iniciais [(descricao, quantidade, valor_unitario, tipo)]
            observacoes (str, optional): Observações iniciais
            
        Returns:
            str: Número do orçamento criado ou None em caso de erro
        """
        try:
            # Gerar número do orçamento
            numero_orcamento = self.gerar_numero_orcamento()
            
            # Definir validade padrão (15 dias)
            data_criacao = datetime.now()
            data_validade = data_criacao + timedelta(days=15)
            
            # Criar workbook para o orçamento
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Orçamento"
            
            # ===== Cabeçalho =====
            ws.merge_cells('A1:H1')
            ws['A1'] = "ORÇAMENTO"
            ws['A1'].font = Font(bold=True, size=16)
            ws['A1'].alignment = Alignment(horizontal='center')
            
            ws.merge_cells('A2:H2')
            ws['A2'] = numero_orcamento
            ws['A2'].font = Font(bold=True, size=14)
            ws['A2'].alignment = Alignment(horizontal='center')
            
            # ===== Informações do cliente =====
            ws['A4'] = "Cliente:"
            ws['B4'] = cliente
            ws['A4'].font = Font(bold=True)
            
            ws['A5'] = "Equipamento:"
            ws['B5'] = equipamento
            ws['A5'].font = Font(bold=True)
            
            ws['A6'] = "Contato:"
            ws['B6'] = contato or ""
            ws['A6'].font = Font(bold=True)
            
            ws['E4'] = "Data:"
            ws['F4'] = data_criacao.strftime("%d/%m/%Y")
            ws['E4'].font = Font(bold=True)
            
            ws['E5'] = "Validade:"
            ws['F5'] = data_validade.strftime("%d/%m/%Y")
            ws['E5'].font = Font(bold=True)
            
            # ===== Itens do orçamento =====
            # Cabeçalho dos itens
            headers = ["Item", "Descrição", "Quantidade", "Valor Unitário", "Subtotal", "Tipo"]
            for col, header in enumerate(headers, start=1):
                cell = ws.cell(row=8, column=col)
                cell.value = header
                cell.font = Font(bold=True)
                cell.alignment = Alignment(horizontal='center')
            
            # Adicionar itens se fornecidos
            row = 9
            valor_total = 0
            
            if items:
                for i, (descricao, quantidade, valor_unitario, tipo) in enumerate(items, start=1):
                    ws.cell(row=row, column=1).value = i
                    ws.cell(row=row, column=2).value = descricao
                    ws.cell(row=row, column=3).value = quantidade
                    ws.cell(row=row, column=4).value = valor_unitario
                    subtotal = quantidade * valor_unitario
                    ws.cell(row=row, column=5).value = subtotal
                    ws.cell(row=row, column=6).value = tipo  # "Peça" ou "Serviço"
                    
                    valor_total += subtotal
                    row += 1
            
            # Adicionar mais linhas em branco para preenchimento posterior
            for _ in range(10):  # Adicionar 10 linhas vazias
                ws.cell(row=row, column=1).value = row - 8  # Número do item
                row += 1
            
            # ===== Totais =====
            total_row = row + 1
            ws.cell(row=total_row, column=4).value = "TOTAL:"
            ws.cell(row=total_row, column=4).font = Font(bold=True)
            ws.cell(row=total_row, column=5).value = valor_total
            ws.cell(row=total_row, column=5).font = Font(bold=True)
            
            # ===== Observações =====
            ws.merge_cells(f'A{total_row+2}:H{total_row+2}')
            ws.cell(row=total_row+2, column=1).value = "OBSERVAÇÕES:"
            ws.cell(row=total_row+2, column=1).font = Font(bold=True)
            
            if observacoes:
                ws.merge_cells(f'A{total_row+3}:H{total_row+5}')
                ws.cell(row=total_row+3, column=1).value = observacoes
                ws.cell(row=total_row+3, column=1).alignment = Alignment(wrap_text=True, vertical='top')
            
            # ===== Assinaturas =====
            assinatura_row = total_row + 7
            ws.merge_cells(f'A{assinatura_row}:D{assinatura_row}')
            ws.cell(row=assinatura_row, column=1).value = "Responsável Técnico"
            ws.cell(row=assinatura_row, column=1).alignment = Alignment(horizontal='center')
            
            ws.merge_cells(f'E{assinatura_row}:H{assinatura_row}')
            ws.cell(row=assinatura_row, column=5).value = "Cliente"
            ws.cell(row=assinatura_row, column=5).alignment = Alignment(horizontal='center')
            
            # ===== Salvar o arquivo =====
            file_path = os.path.join(self.base_path, "pendentes", f"{numero_orcamento}.xlsx")
            wb.save(file_path)
            
            # Registrar no arquivo de controle
            self._registrar_orcamento(numero_orcamento, cliente, equipamento, 
                                     data_criacao, data_validade, valor_total)
            
            print(f"Orçamento {numero_orcamento} criado com sucesso em: {file_path}")
            return numero_orcamento
            
        except Exception as e:
            print(f"Erro ao criar orçamento: {e}")
            return None
    
    def _registrar_orcamento(self, numero, cliente, equipamento, data_criacao, 
                            data_validade, valor_total, status="Pendente"):
        """
        Registra um orçamento no arquivo de controle.
        
        Args:
            numero (str): Número do orçamento
            cliente (str): Nome do cliente
            equipamento (str): Descrição do equipamento
            data_criacao (datetime): Data de criação
            data_validade (datetime): Data de validade
            valor_total (float): Valor total do orçamento
            status (str, optional): Status inicial (padrão: "Pendente")
        """
        try:
            wb = openpyxl.load_workbook(self.controle_file)
            ws = wb.active
            
            # Próxima linha disponível
            next_row = ws.max_row + 1
            
            # Adicionar registro
            ws.cell(row=next_row, column=1).value = numero
            ws.cell(row=next_row, column=2).value = cliente
            ws.cell(row=next_row, column=3).value = equipamento
            ws.cell(row=next_row, column=4).value = data_criacao.strftime("%d/%m/%Y")
            ws.cell(row=next_row, column=5).value = data_validade.strftime("%d/%m/%Y")
            ws.cell(row=next_row, column=6).value = valor_total
            ws.cell(row=next_row, column=7).value = status
            
            # Salvar alterações
            wb.save(self.controle_file)
            
        except Exception as e:
            print(f"Erro ao registrar orçamento no controle: {e}")
    
    def listar_orcamentos(self, status=None):
        """
        Lista todos os orçamentos ou filtra por status.
        
        Args:
            status (str, optional): Filtrar por status específico
            
        Returns:
            list: Lista de dicionários com informações dos orçamentos
        """
        try:
            wb = openpyxl.load_workbook(self.controle_file)
            ws = wb.active
            
            # Obter cabeçalhos
            headers = [cell.value for cell in ws[1]]
            
            orcamentos = []
            for row in range(2, ws.max_row + 1):
                orcamento = {headers[col-1]: ws.cell(row=row, column=col).value 
                            for col in range(1, len(headers) + 1)}
                
                # Filtrar por status se especificado
                if status is None or orcamento['Status'] == status:
                    orcamentos.append(orcamento)
            
            return orcamentos
            
        except Exception as e:
            print(f"Erro ao listar orçamentos: {e}")
            return []
    
    def atualizar_status(self, numero_orcamento, novo_status, aprovado_por=None, numero_os=None):
        """
        Atualiza o status de um orçamento.
        
        Args:
            numero_orcamento (str): Número do orçamento
            novo_status (str): Novo status ("Aprovado", "Rejeitado", "Convertido")
            aprovado_por (str, optional): Nome de quem aprovou (se aplicável)
            numero_os (str, optional): Número da OS quando convertido
            
        Returns:
            bool: True se atualizado com sucesso, False caso contrário
        """
        try:
            wb = openpyxl.load_workbook(self.controle_file)
            ws = wb.active
            
            # Buscar orçamento
            linha_orcamento = None
            for row in range(2, ws.max_row + 1):
                if ws.cell(row=row, column=1).value == numero_orcamento:
                    linha_orcamento = row
                    break
            
            if linha_orcamento is None:
                print(f"Orçamento {numero_orcamento} não encontrado.")
                return False
            
            # Atualizar status
            ws.cell(row=linha_orcamento, column=7).value = novo_status
            
            # Atualizar informações adicionais conforme o status
            if novo_status == "Aprovado" or novo_status == "Convertido":
                ws.cell(row=linha_orcamento, column=8).value = aprovado_por
                ws.cell(row=linha_orcamento, column=9).value = datetime.now().strftime("%d/%m/%Y")
                
                if novo_status == "Convertido" and numero_os:
                    ws.cell(row=linha_orcamento, column=10).value = numero_os
            
            # Salvar alterações no arquivo de controle
            wb.save(self.controle_file)
            
            # Mover arquivo para a pasta correspondente ao novo status
            status_pasta_map = {
                "Aprovado": "aprovados",
                "Rejeitado": "rejeitados",
                "Convertido": "convertidos",
                "Pendente": "pendentes"
            }
            pasta_destino = status_pasta_map.get(novo_status, "pendentes")
            self._mover_arquivo_orcamento(numero_orcamento, pasta_destino)
            
            print(f"Status do orçamento {numero_orcamento} atualizado para {novo_status}.")
            return True
            
        except Exception as e:
            print(f"Erro ao atualizar status do orçamento: {e}")
            return False
    
    def _mover_arquivo_orcamento(self, numero_orcamento, status_pasta):
        """
        Move o arquivo de orçamento para a pasta correspondente ao seu status.
        
        Args:
            numero_orcamento (str): Número do orçamento
            status_pasta (str): Nome da pasta de destino (pendentes, aprovados, rejeitados, convertidos)
        """
        try:
            # Determinar pasta atual
            arquivo_encontrado = False
            for pasta in ["pendentes", "aprovados", "rejeitados", "convertidos"]:
                origem = os.path.join(self.base_path, pasta, f"{numero_orcamento}.xlsx")
                if os.path.exists(origem):
                    arquivo_encontrado = True
                    destino = os.path.join(self.base_path, status_pasta, f"{numero_orcamento}.xlsx")
                    
                    # Se origem e destino são diferentes, mover o arquivo
                    if origem != destino:
                        # Criar diretório de destino se não existir
                        dir_destino = os.path.dirname(destino)
                        if not os.path.exists(dir_destino):
                            os.makedirs(dir_destino)
                            
                        os.rename(origem, destino)
                        print(f"Arquivo movido para: {destino}")
                    break
                    
            if not arquivo_encontrado:
                print(f"Arquivo do orçamento {numero_orcamento} não encontrado em nenhuma pasta.")
        except Exception as e:
            print(f"Erro ao mover arquivo: {e}")

    def buscar_orcamento(self, numero_orcamento):
        """
        Busca informações de um orçamento específico.
        
        Args:
            numero_orcamento (str): Número do orçamento a ser buscado
            
        Returns:
            dict: Informações do orçamento ou None se não encontrado
        """
        try:
            wb = openpyxl.load_workbook(self.controle_file)
            ws = wb.active
            
            # Obter cabeçalhos
            headers = [cell.value for cell in ws[1]]
            
            # Buscar orçamento
            for row in range(2, ws.max_row + 1):
                if ws.cell(row=row, column=1).value == numero_orcamento:
                    orcamento = {headers[col-1]: ws.cell(row=row, column=col).value 
                                for col in range(1, len(headers) + 1)}
                    return orcamento
            
            print(f"Orçamento {numero_orcamento} não encontrado.")
            return None
            
        except Exception as e:
            print(f"Erro ao buscar orçamento: {e}")
            return None

# Exemplo de uso simples
if __name__ == "__main__":
    gerenciador = GerenciadorOrcamentos()
    
    # Criar um orçamento de exemplo
    itens_exemplo = [
        ("Placa controladora", 1, 1200.50, "Peça"),
        ("Serviço de reparo", 2, 350.00, "Serviço")
    ]
    
    numero = gerenciador.criar_orcamento(
        cliente="Empresa Exemplo Ltda",
        equipamento="Arco Cirúrgico Ziehm Vision RFD",
        contato="João Silva - (11) 98765-4321",
        items=itens_exemplo,
        observacoes="Urgente - Cliente precisa do equipamento até o final da semana."
    )
    
    if numero:
        print(f"\nOrçamento criado: {numero}")
        
        # Listar orçamentos pendentes
        print("\nOrçamentos pendentes:")
        for orc in gerenciador.listar_orcamentos(status="Pendente"):
            print(f"- {orc['Número']} | {orc['Cliente']} | R$ {orc['Valor Total']}")
        
        # Simular aprovação
        gerenciador.atualizar_status(numero, "Aprovado", aprovado_por="João Silva") 