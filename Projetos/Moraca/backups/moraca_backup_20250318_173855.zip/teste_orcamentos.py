from orcamentos import GerenciadorOrcamentos
import time

def main():
    print("=== TESTE DO MÓDULO DE ORÇAMENTOS ===")
    gerenciador = GerenciadorOrcamentos()
    
    # Teste 1: Criar alguns orçamentos de exemplo
    print("\n== Teste 1: Criando orçamentos de exemplo ==")
    
    # Orçamento 1
    itens1 = [
        ("Placa de controle Ziehm", 1, 3500.00, "Peça"),
        ("Cabo de alimentação", 2, 150.00, "Peça"),
        ("Serviço de instalação", 4, 250.00, "Serviço")
    ]
    
    orc1 = gerenciador.criar_orcamento(
        cliente="Hospital Santa Maria",
        equipamento="Arco Cirúrgico Ziehm Vision RFD",
        contato="Dr. Carlos - (11) 98765-4321",
        items=itens1,
        observacoes="Cliente precisa do equipamento para cirurgia de emergência."
    )
    
    # Pequena pausa para garantir números de orçamentos diferentes
    time.sleep(1)
    
    # Orçamento 2
    itens2 = [
        ("Display LCD 19 polegadas", 1, 1200.00, "Peça"),
        ("Serviço de calibração", 1, 800.00, "Serviço")
    ]
    
    orc2 = gerenciador.criar_orcamento(
        cliente="Clínica Saúde Total",
        equipamento="Monitor Multiparâmetros",
        contato="Dra. Ana - (21) 97654-3210",
        items=itens2
    )
    
    # Teste 2: Listar orçamentos
    print("\n== Teste 2: Listando todos os orçamentos ==")
    orcamentos = gerenciador.listar_orcamentos()
    
    print(f"Total de orçamentos: {len(orcamentos)}")
    for orc in orcamentos:
        print(f"- {orc['Número']} | {orc['Cliente']} | Equip: {orc['Equipamento']} | Valor: R$ {orc['Valor Total']}")
    
    # Teste 3: Atualizar status de um orçamento
    if orc1:
        print(f"\n== Teste 3: Atualizando status do orçamento {orc1} ==")
        gerenciador.atualizar_status(orc1, "Aprovado", aprovado_por="Dr. Carlos")
        
        # Verificar se o status foi atualizado
        orc_info = gerenciador.buscar_orcamento(orc1)
        if orc_info:
            print(f"Novo status: {orc_info['Status']}")
            print(f"Aprovado por: {orc_info['Aprovado Por']}")
            print(f"Data de aprovação: {orc_info['Data Aprovação']}")
    
    # Teste 4: Converter orçamento em OS
    if orc2:
        print(f"\n== Teste 4: Convertendo orçamento {orc2} em OS ==")
        gerenciador.atualizar_status(orc2, "Convertido", aprovado_por="Dra. Ana", numero_os="OS12345")
        
        # Verificar a conversão
        orc_info = gerenciador.buscar_orcamento(orc2)
        if orc_info:
            print(f"Novo status: {orc_info['Status']}")
            print(f"Convertido em OS: {orc_info['Convertido em OS']}")
    
    # Teste 5: Listar orçamentos por status
    print("\n== Teste 5: Listando orçamentos por status ==")
    
    print("\nOrçamentos Aprovados:")
    for orc in gerenciador.listar_orcamentos(status="Aprovado"):
        print(f"- {orc['Número']} | {orc['Cliente']} | Aprovado por: {orc['Aprovado Por']}")
    
    print("\nOrçamentos Convertidos:")
    for orc in gerenciador.listar_orcamentos(status="Convertido"):
        print(f"- {orc['Número']} | {orc['Cliente']} | OS: {orc['Convertido em OS']}")
    
    print("\nTestes concluídos com sucesso!")
    print(f"Os arquivos de orçamentos foram criados em: {gerenciador.base_path}")

if __name__ == "__main__":
    main() 