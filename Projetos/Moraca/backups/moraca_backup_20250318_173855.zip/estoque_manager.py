import openpyxl
import os
from datetime import datetime
import pandas as pd

class EstoqueManager:
    """
    Classe para gerenciar o sistema de estoque usando arquivos Excel como base de dados.
    Permite adicionar, remover, atualizar e pesquisar itens no estoque.
    """
    
    def __init__(self, base_path=None):
        """
        Inicializa o gerenciador de estoque.
        
        Args:
            base_path (str, optional): Caminho base onde os arquivos de estoque serão armazenados.
                                      Se None, usa o caminho padrão.
        """
        if base_path is None:
            self.base_path = os.path.join("MORACA", "MORACA1", "ESTOQUE")
        else:
            self.base_path = base_path
            
        # Arquivos de estoque para diferentes categorias
        self.estoque_geral_file = os.path.join(self.base_path, "estoque_geral.xlsx")
        self.estoque_ziehm_file = os.path.join(self.base_path, "estoque_ziehm.xlsx")
        self.estoque_moraca_file = os.path.join(self.base_path, "estoque_moraca.xlsx")
        
        # Garantir que a estrutura de pastas e arquivos existe
        self._inicializar_estrutura()
    
    def _inicializar_estrutura(self):
        """Inicializa a estrutura de pastas e arquivos necessários para o sistema de estoque."""
        # Criar pasta base se não existir
        if not os.path.exists(self.base_path):
            os.makedirs(self.base_path)
        
        # Criar arquivos de estoque se não existirem
        for file_path in [self.estoque_geral_file, self.estoque_ziehm_file, self.estoque_moraca_file]:
            if not os.path.exists(file_path):
                self._criar_arquivo_estoque(file_path)
    
    def _criar_arquivo_estoque(self, file_path):
        """
        Cria um arquivo de estoque com a estrutura básica.
        
        Args:
            file_path (str): Caminho do arquivo a ser criado.
        """
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Estoque"
        
        # Definir cabeçalhos
        headers = ["Código", "Descrição", "Quantidade", "Localização", "Fabricante", 
                  "Modelo", "Preço Unitário", "Data Última Atualização", "Observações"]
        
        for col, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col)
            cell.value = header
            cell.font = openpyxl.styles.Font(bold=True)
            cell.alignment = openpyxl.styles.Alignment(horizontal='center')
        
        # Configurar larguras das colunas
        ws.column_dimensions['A'].width = 15  # Código
        ws.column_dimensions['B'].width = 40  # Descrição
        ws.column_dimensions['C'].width = 12  # Quantidade
        ws.column_dimensions['D'].width = 20  # Localização
        ws.column_dimensions['E'].width = 20  # Fabricante
        ws.column_dimensions['F'].width = 20  # Modelo
        ws.column_dimensions['G'].width = 15  # Preço Unitário
        ws.column_dimensions['H'].width = 20  # Data Última Atualização
        ws.column_dimensions['I'].width = 30  # Observações
        
        # Salvar arquivo
        wb.save(file_path)
        print(f"Arquivo de estoque criado em: {file_path}")
    
    def adicionar_item(self, categoria, codigo, descricao, quantidade, localizacao=None, 
                      fabricante=None, modelo=None, preco=None, observacoes=None):
        """
        Adiciona um item ao estoque.
        
        Args:
            categoria (str): Categoria do item ('geral', 'ziehm', ou 'moraca').
            codigo (str): Código único do item.
            descricao (str): Descrição do item.
            quantidade (int): Quantidade inicial do item.
            localizacao (str, optional): Localização do item no estoque.
            fabricante (str, optional): Fabricante do item.
            modelo (str, optional): Modelo do item.
            preco (float, optional): Preço unitário do item.
            observacoes (str, optional): Observações adicionais sobre o item.
            
        Returns:
            bool: True se o item foi adicionado com sucesso, False caso contrário.
        """
        # Determinar o arquivo de estoque com base na categoria
        file_path = self._get_file_path(categoria)
        
        try:
            # Carregar arquivo
            wb = openpyxl.load_workbook(file_path)
            ws = wb.active
            
            # Verificar se o código já existe
            for row in range(2, ws.max_row + 1):
                if ws.cell(row=row, column=1).value == codigo:
                    print(f"Item com código {codigo} já existe.")
                    return False
            
            # Adicionar novo item
            next_row = ws.max_row + 1
            
            ws.cell(row=next_row, column=1).value = codigo
            ws.cell(row=next_row, column=2).value = descricao
            ws.cell(row=next_row, column=3).value = quantidade
            ws.cell(row=next_row, column=4).value = localizacao
            ws.cell(row=next_row, column=5).value = fabricante
            ws.cell(row=next_row, column=6).value = modelo
            ws.cell(row=next_row, column=7).value = preco
            ws.cell(row=next_row, column=8).value = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
            ws.cell(row=next_row, column=9).value = observacoes
            
            # Salvar alterações
            wb.save(file_path)
            print(f"Item {codigo} adicionado com sucesso ao estoque {categoria}.")
            return True
            
        except Exception as e:
            print(f"Erro ao adicionar item: {e}")
            return False
    
    def atualizar_quantidade(self, categoria, codigo, quantidade_delta, observacao=None):
        """
        Atualiza a quantidade de um item no estoque.
        
        Args:
            categoria (str): Categoria do item ('geral', 'ziehm', ou 'moraca').
            codigo (str): Código do item a ser atualizado.
            quantidade_delta (int): Variação na quantidade (positivo para adicionar, negativo para remover).
            observacao (str, optional): Observação sobre a movimentação.
            
        Returns:
            bool: True se a quantidade foi atualizada com sucesso, False caso contrário.
        """
        file_path = self._get_file_path(categoria)
        
        try:
            # Carregar arquivo
            wb = openpyxl.load_workbook(file_path)
            ws = wb.active
            
            # Buscar item
            item_encontrado = False
            for row in range(2, ws.max_row + 1):
                if ws.cell(row=row, column=1).value == codigo:
                    # Atualizar quantidade
                    quantidade_atual = ws.cell(row=row, column=3).value or 0
                    nova_quantidade = quantidade_atual + quantidade_delta
                    
                    # Verificar se ficaria negativo
                    if nova_quantidade < 0:
                        print(f"Erro: Quantidade insuficiente. Disponível: {quantidade_atual}")
                        return False
                    
                    ws.cell(row=row, column=3).value = nova_quantidade
                    ws.cell(row=row, column=8).value = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                    
                    # Atualizar observações se fornecidas
                    if observacao:
                        obs_antigas = ws.cell(row=row, column=9).value or ""
                        nova_obs = f"{obs_antigas}\n{datetime.now().strftime('%d/%m/%Y')}: {observacao}"
                        ws.cell(row=row, column=9).value = nova_obs
                    
                    item_encontrado = True
                    break
            
            if not item_encontrado:
                print(f"Item com código {codigo} não encontrado.")
                return False
                
            # Salvar alterações
            wb.save(file_path)
            print(f"Quantidade do item {codigo} atualizada com sucesso. Nova quantidade: {nova_quantidade}")
            return True
            
        except Exception as e:
            print(f"Erro ao atualizar quantidade: {e}")
            return False
    
    def atualizar_item(self, categoria, codigo, **kwargs):
        """
        Atualiza informações de um item no estoque.
        
        Args:
            categoria (str): Categoria do item ('geral', 'ziehm', ou 'moraca').
            codigo (str): Código do item a ser atualizado.
            **kwargs: Campos a serem atualizados (descricao, localizacao, fabricante, modelo, preco).
            
        Returns:
            bool: True se o item foi atualizado com sucesso, False caso contrário.
        """
        file_path = self._get_file_path(categoria)
        
        # Mapeamento de nomes de campos para números de colunas
        campo_para_coluna = {
            'descricao': 2,
            'quantidade': 3,
            'localizacao': 4,
            'fabricante': 5,
            'modelo': 6,
            'preco': 7,
            'observacoes': 9
        }
        
        try:
            # Carregar arquivo
            wb = openpyxl.load_workbook(file_path)
            ws = wb.active
            
            # Buscar item
            item_encontrado = False
            for row in range(2, ws.max_row + 1):
                if ws.cell(row=row, column=1).value == codigo:
                    # Atualizar cada campo fornecido
                    for campo, valor in kwargs.items():
                        if campo in campo_para_coluna:
                            ws.cell(row=row, column=campo_para_coluna[campo]).value = valor
                    
                    # Atualizar data de modificação
                    ws.cell(row=row, column=8).value = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                    
                    item_encontrado = True
                    break
            
            if not item_encontrado:
                print(f"Item com código {codigo} não encontrado.")
                return False
                
            # Salvar alterações
            wb.save(file_path)
            print(f"Item {codigo} atualizado com sucesso.")
            return True
            
        except Exception as e:
            print(f"Erro ao atualizar item: {e}")
            return False
    
    def pesquisar_item(self, categoria, termo, campo='todos'):
        """
        Pesquisa itens no estoque.
        
        Args:
            categoria (str): Categoria do item ('geral', 'ziehm', 'moraca').
            termo (str): Termo de pesquisa.
            campo (str, optional): Campo específico para pesquisar ('codigo', 'descricao', etc.) ou 'todos'.
            
        Returns:
            list: Lista de itens encontrados.
        """
        file_path = self._get_file_path(categoria)
        resultado = []
        
        # Mapeamento de nomes de campos para números de colunas
        campo_para_coluna = {
            'codigo': 1,
            'descricao': 2,
            'quantidade': 3,
            'localizacao': 4,
            'fabricante': 5,
            'modelo': 6,
            'preco': 7,
            'data': 8,
            'observacoes': 9,
            'todos': None  # Pesquisar em todos os campos
        }
        
        try:
            # Carregar arquivo como DataFrame para facilitar a pesquisa
            df = pd.read_excel(file_path)
            
            # Termo vazio, retornar todos os itens
            if not termo:
                return df.to_dict('records')
            
            # Filtrar com base no campo e termo
            if campo == 'todos':
                # Pesquisar em todos os campos de texto
                mask = df.applymap(lambda x: str(x).lower().find(termo.lower()) >= 0 if isinstance(x, str) else False).any(axis=1)
                resultado = df[mask].to_dict('records')
            else:
                # Pesquisar em um campo específico
                coluna = list(df.columns)[campo_para_coluna[campo] - 1]  # Ajustar para índice baseado em 0
                
                # Verificar se a coluna é numérica
                if df[coluna].dtype.kind in 'fc':  # float ou complex
                    try:
                        valor = float(termo)
                        mask = df[coluna] == valor
                    except:
                        mask = df[coluna].astype(str).str.contains(termo, case=False)
                else:
                    mask = df[coluna].astype(str).str.contains(termo, case=False)
                
                resultado = df[mask].to_dict('records')
            
            return resultado
            
        except Exception as e:
            print(f"Erro ao pesquisar item: {e}")
            return []
    
    def listar_todos_itens(self, categoria):
        """
        Lista todos os itens de uma categoria.
        
        Args:
            categoria (str): Categoria dos itens ('geral', 'ziehm', 'moraca').
            
        Returns:
            list: Lista de todos os itens da categoria.
        """
        file_path = self._get_file_path(categoria)
        
        try:
            df = pd.read_excel(file_path)
            return df.to_dict('records')
        except Exception as e:
            print(f"Erro ao listar itens: {e}")
            return []
    
    def _get_file_path(self, categoria):
        """
        Retorna o caminho do arquivo de estoque com base na categoria.
        
        Args:
            categoria (str): Categoria ('geral', 'ziehm', 'moraca').
            
        Returns:
            str: Caminho do arquivo de estoque.
        """
        if categoria.lower() == 'geral':
            return self.estoque_geral_file
        elif categoria.lower() == 'ziehm':
            return self.estoque_ziehm_file
        elif categoria.lower() == 'moraca':
            return self.estoque_moraca_file
        else:
            # Categoria inválida, usar estoque geral
            print(f"Categoria '{categoria}' inválida. Usando estoque geral.")
            return self.estoque_geral_file
    
    def registrar_movimentacao(self, categoria, codigo, tipo, quantidade, responsavel, observacao=None):
        """
        Registra uma movimentação no histórico de movimentações.
        
        Args:
            categoria (str): Categoria do item ('geral', 'ziehm', 'moraca').
            codigo (str): Código do item.
            tipo (str): Tipo de movimentação ('entrada', 'saida', 'ajuste').
            quantidade (int): Quantidade movimentada.
            responsavel (str): Nome do responsável pela movimentação.
            observacao (str, optional): Observação sobre a movimentação.
            
        Returns:
            bool: True se a movimentação foi registrada com sucesso, False caso contrário.
        """
        historico_file = os.path.join(self.base_path, "historico_movimentacoes.xlsx")
        
        # Criar arquivo de histórico se não existir
        if not os.path.exists(historico_file):
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Histórico"
            
            # Definir cabeçalhos
            headers = ["Data/Hora", "Categoria", "Código", "Tipo", "Quantidade", 
                       "Responsável", "Observação"]
            
            for col, header in enumerate(headers, start=1):
                cell = ws.cell(row=1, column=col)
                cell.value = header
                cell.font = openpyxl.styles.Font(bold=True)
            
            wb.save(historico_file)
        
        try:
            # Carregar arquivo de histórico
            wb = openpyxl.load_workbook(historico_file)
            ws = wb.active
            
            # Adicionar nova movimentação
            next_row = ws.max_row + 1
            
            ws.cell(row=next_row, column=1).value = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
            ws.cell(row=next_row, column=2).value = categoria
            ws.cell(row=next_row, column=3).value = codigo
            ws.cell(row=next_row, column=4).value = tipo
            ws.cell(row=next_row, column=5).value = quantidade
            ws.cell(row=next_row, column=6).value = responsavel
            ws.cell(row=next_row, column=7).value = observacao
            
            # Salvar alterações
            wb.save(historico_file)
            print(f"Movimentação registrada com sucesso.")
            return True
            
        except Exception as e:
            print(f"Erro ao registrar movimentação: {e}")
            return False

# Exemplo de uso
if __name__ == "__main__":
    # Criar instância do gerenciador de estoque
    estoque = EstoqueManager()
    
    # Adicionar alguns itens de exemplo
    estoque.adicionar_item('geral', 'ABC123', 'Peça de teste 1', 10, 'Prateleira A', 'Fabricante XYZ', 'Modelo 123', 100.50)
    estoque.adicionar_item('ziehm', 'Z12345', 'Componente Ziehm', 5, 'Armário Z', 'Ziehm', 'Vision RFD', 1500.00)
    
    # Atualizar quantidade
    estoque.atualizar_quantidade('geral', 'ABC123', -2, "Retirada para manutenção")
    
    # Pesquisar item
    resultados = estoque.pesquisar_item('geral', 'teste')
    print(f"Resultados da pesquisa: {resultados}") 