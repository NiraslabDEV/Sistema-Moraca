from estoque_manager import EstoqueManager
import os

def main():
    # Definir um caminho temporário para testes
    temp_base_path = os.path.join(os.getcwd(), "temp_estoque")
    
    print("=== TESTE DO MÓDULO ESTOQUE MANAGER ===")
    print(f"Criando estrutura temporária em: {temp_base_path}")
    
    # Criar instância do gerenciador de estoque
    estoque = EstoqueManager(base_path=temp_base_path)
    
    # Teste 1: Adicionar itens
    print("\n== Teste 1: Adicionando itens ==")
    estoque.adicionar_item('geral', 'TEST001', 'Item de teste 1', 10, 'Prateleira A', 
                          'Fabricante X', 'Modelo X1', 150.00, 'Item para testes')
    estoque.adicionar_item('ziehm', 'Z001', 'Peça Ziehm', 5, 'Armário Z', 
                          'Ziehm', 'Vision RFD', 2500.00, 'Importado')
    estoque.adicionar_item('moraca', 'M001', 'Produto Moraca', 20, 'Estante M', 
                          'Moraca', 'Padrão', 75.50, 'Produto próprio')
    
    # Teste 2: Listar todos os itens
    print("\n== Teste 2: Listando todos os itens ==")
    print("\nItens no estoque geral:")
    itens_geral = estoque.listar_todos_itens('geral')
    for item in itens_geral:
        print(f"Código: {item['Código']}, Descrição: {item['Descrição']}, Qtde: {item['Quantidade']}")
    
    print("\nItens no estoque Ziehm:")
    itens_ziehm = estoque.listar_todos_itens('ziehm')
    for item in itens_ziehm:
        print(f"Código: {item['Código']}, Descrição: {item['Descrição']}, Qtde: {item['Quantidade']}")
    
    # Teste 3: Atualizar quantidade
    print("\n== Teste 3: Atualizando quantidades ==")
    estoque.atualizar_quantidade('geral', 'TEST001', -3, "Retirada para uso em manutenção")
    estoque.atualizar_quantidade('ziehm', 'Z001', 2, "Entrada por devolução")
    
    print("\nQuantidades após atualização:")
    for item in estoque.listar_todos_itens('geral'):
        if item['Código'] == 'TEST001':
            print(f"TEST001 nova quantidade: {item['Quantidade']}")
    
    for item in estoque.listar_todos_itens('ziehm'):
        if item['Código'] == 'Z001':
            print(f"Z001 nova quantidade: {item['Quantidade']}")
    
    # Teste 4: Pesquisar itens
    print("\n== Teste 4: Pesquisando itens ==")
    resultados = estoque.pesquisar_item('geral', 'teste', 'descricao')
    print(f"Resultados da pesquisa por 'teste' na descrição:")
    for item in resultados:
        print(f"Código: {item['Código']}, Descrição: {item['Descrição']}")
    
    # Teste 5: Atualizar detalhes de um item
    print("\n== Teste 5: Atualizando detalhes de item ==")
    estoque.atualizar_item('moraca', 'M001', descricao='Produto Moraca Premium', preco=95.00)
    
    print("\nDetalhes após atualização:")
    for item in estoque.listar_todos_itens('moraca'):
        if item['Código'] == 'M001':
            print(f"M001 nova descrição: {item['Descrição']}")
            print(f"M001 novo preço: {item['Preço Unitário']}")
    
    # Teste 6: Registrar movimentação no histórico
    print("\n== Teste 6: Registrando movimentação ==")
    estoque.registrar_movimentacao('geral', 'TEST001', 'saida', 2, 'Gabriel', 'Teste de saída')
    estoque.registrar_movimentacao('ziehm', 'Z001', 'entrada', 5, 'Gabriel', 'Teste de entrada')
    
    print("\nMovimentações registradas com sucesso.")
    print("\nTestes concluídos.")
    
    return temp_base_path

if __name__ == "__main__":
    temp_dir = main()
    print(f"\nArquivos de teste foram criados em: {temp_dir}")
    print(f"Você pode verificar os arquivos Excel gerados nesse diretório.") 