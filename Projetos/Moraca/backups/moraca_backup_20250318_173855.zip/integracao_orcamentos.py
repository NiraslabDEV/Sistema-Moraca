"""
Módulo de integração do sistema de orçamentos com o sistema principal.
Este módulo fornece funções para criar, gerenciar e converter orçamentos em OS.
"""

from orcamentos import GerenciadorOrcamentos
import os
import sys
import openpyxl
from datetime import datetime

# Instância global do gerenciador de orçamentos
gerenciador = GerenciadorOrcamentos()

def criar_novo_orcamento(cliente, equipamento, contato=None, items=None, observacoes=None):
    """
    Cria um novo orçamento no sistema.
    
    Args:
        cliente (str): Nome do cliente
        equipamento (str): Descrição do equipamento
        contato (str, optional): Informações de contato
        items (list, optional): Lista de itens [(descricao, quantidade, valor_unitario, tipo)]
        observacoes (str, optional): Observações iniciais
        
    Returns:
        str: Número do orçamento criado ou None em caso de erro
    """
    return gerenciador.criar_orcamento(cliente, equipamento, contato, items, observacoes)

def listar_todos_orcamentos():
    """
    Lista todos os orçamentos registrados no sistema.
    
    Returns:
        list: Lista de dicionários com informações dos orçamentos
    """
    return gerenciador.listar_orcamentos()

def listar_orcamentos_por_status(status):
    """
    Lista orçamentos com um status específico.
    
    Args:
        status (str): Status desejado ("Pendente", "Aprovado", "Rejeitado", "Convertido")
        
    Returns:
        list: Lista filtrada de orçamentos
    """
    return gerenciador.listar_orcamentos(status=status)

def buscar_orcamento_por_numero(numero_orcamento):
    """
    Busca informações de um orçamento específico.
    
    Args:
        numero_orcamento (str): Número do orçamento
        
    Returns:
        dict: Informações do orçamento ou None se não encontrado
    """
    return gerenciador.buscar_orcamento(numero_orcamento)

def aprovar_orcamento(numero_orcamento, aprovado_por):
    """
    Marca um orçamento como aprovado.
    
    Args:
        numero_orcamento (str): Número do orçamento
        aprovado_por (str): Nome de quem aprovou
        
    Returns:
        bool: True se atualizado com sucesso, False caso contrário
    """
    return gerenciador.atualizar_status(numero_orcamento, "Aprovado", aprovado_por=aprovado_por)

def rejeitar_orcamento(numero_orcamento, motivo=None):
    """
    Marca um orçamento como rejeitado.
    
    Args:
        numero_orcamento (str): Número do orçamento
        motivo (str, optional): Motivo da rejeição
        
    Returns:
        bool: True se atualizado com sucesso, False caso contrário
    """
    # Adicionar motivo às observações do orçamento antes de rejeitar
    if motivo:
        try:
            # Localizar o arquivo do orçamento
            for pasta in ["pendentes", "aprovados"]:  # Orçamentos a serem rejeitados normalmente estão nestas pastas
                file_path = os.path.join(gerenciador.base_path, pasta, f"{numero_orcamento}.xlsx")
                if os.path.exists(file_path):
                    # Adicionar motivo nas observações
                    wb = openpyxl.load_workbook(file_path)
                    ws = wb.active
                    
                    # Buscar seção de observações (normalmente começa na linha após os itens e totais)
                    obs_row = None
                    for row in range(8, ws.max_row):
                        if ws.cell(row=row, column=1).value == "OBSERVAÇÕES:":
                            obs_row = row
                            break
                    
                    if obs_row:
                        # Adicionar motivo da rejeição nas observações
                        atual_obs = ws.cell(row=obs_row+1, column=1).value or ""
                        nova_obs = f"{atual_obs}\n\nREJEITADO EM {datetime.now().strftime('%d/%m/%Y')}: {motivo}"
                        ws.cell(row=obs_row+1, column=1).value = nova_obs
                        
                        # Salvar alterações
                        wb.save(file_path)
                        break
        except Exception as e:
            print(f"Erro ao adicionar motivo de rejeição: {e}")
    
    # Atualizar status
    return gerenciador.atualizar_status(numero_orcamento, "Rejeitado")

def converter_orcamento_em_os(numero_orcamento, numero_os, responsavel):
    """
    Converte um orçamento aprovado em uma Ordem de Serviço.
    
    Args:
        numero_orcamento (str): Número do orçamento
        numero_os (str): Número da OS a ser criada
        responsavel (str): Nome do responsável pela conversão
        
    Returns:
        bool: True se convertido com sucesso, False caso contrário
    """
    # Primeiro, verificar se o orçamento existe e está aprovado
    orcamento = gerenciador.buscar_orcamento(numero_orcamento)
    if not orcamento:
        print(f"Orçamento {numero_orcamento} não encontrado.")
        return False
    
    if orcamento['Status'] != "Aprovado":
        print(f"Orçamento {numero_orcamento} não está aprovado. Status atual: {orcamento['Status']}")
        return False
    
    # Atualizar status para convertido
    return gerenciador.atualizar_status(numero_orcamento, "Convertido", 
                                      aprovado_por=responsavel, 
                                      numero_os=numero_os)

def obter_dados_para_os(numero_orcamento):
    """
    Obtém os dados de um orçamento para inicializar uma OS.
    
    Args:
        numero_orcamento (str): Número do orçamento
        
    Returns:
        dict: Dicionário com informações para criar a OS ou None em caso de erro
    """
    try:
        # Verificar se o orçamento existe
        orcamento = gerenciador.buscar_orcamento(numero_orcamento)
        if not orcamento:
            print(f"Orçamento {numero_orcamento} não encontrado.")
            return None
        
        # Localizar o arquivo do orçamento para extrair itens
        arquivo_orcamento = None
        for pasta in ["aprovados", "pendentes", "convertidos"]:
            caminho = os.path.join(gerenciador.base_path, pasta, f"{numero_orcamento}.xlsx")
            if os.path.exists(caminho):
                arquivo_orcamento = caminho
                break
        
        if not arquivo_orcamento:
            print(f"Arquivo do orçamento {numero_orcamento} não encontrado.")
            return None
        
        # Extrair dados do arquivo
        wb = openpyxl.load_workbook(arquivo_orcamento)
        ws = wb.active
        
        # Obter itens do orçamento
        itens = []
        row = 9  # Início dos itens (normalmente após os cabeçalhos)
        
        # Enquanto houver itens válidos
        while row < ws.max_row and ws.cell(row=row, column=2).value:
            item = {
                "descricao": ws.cell(row=row, column=2).value,
                "quantidade": ws.cell(row=row, column=3).value,
                "valor": ws.cell(row=row, column=4).value,
                "tipo": ws.cell(row=row, column=6).value
            }
            itens.append(item)
            row += 1
        
        # Obter observações
        observacoes = None
        for row in range(row, ws.max_row):
            if ws.cell(row=row, column=1).value == "OBSERVAÇÕES:":
                observacoes = ws.cell(row=row+1, column=1).value
                break
        
        # Montar dados para a OS
        dados_os = {
            "cliente": orcamento["Cliente"],
            "equipamento": orcamento["Equipamento"],
            "itens": itens,
            "observacoes": observacoes,
            "orcamento_origem": numero_orcamento,
            "valor_total": orcamento["Valor Total"]
        }
        
        return dados_os
        
    except Exception as e:
        print(f"Erro ao obter dados para OS: {e}")
        return None

# Funções de exemplo para integração com a interface principal
def exemplo_criar_orcamento_interface():
    """Exemplo de como seria a criação de orçamento a partir da interface principal."""
    # Na interface, esses dados viriam de campos de formulário
    cliente = "Hospital Modelo"
    equipamento = "Arco Cirúrgico Ziehm Vision FD"
    contato = "Dr. José Silva - (11) 12345-6789"
    
    # Itens viriam de uma tabela na interface
    itens = [
        ("Monitor LCD 24pol", 1, 2500.00, "Peça"),
        ("Placa de controle principal", 1, 4800.00, "Peça"),
        ("Serviço de instalação", 3, 350.00, "Serviço"),
    ]
    
    observacoes = "Cliente solicitou urgência. Equipamento parado desde 10/03."
    
    # Chamar função de criação
    numero = criar_novo_orcamento(cliente, equipamento, contato, itens, observacoes)
    if numero:
        print(f"Orçamento {numero} criado com sucesso!")
    else:
        print("Erro ao criar orçamento.")
    
    return numero

def exemplo_fluxo_completo():
    """Exemplo de um fluxo completo: criar orçamento, aprovar e converter em OS."""
    # 1. Criar orçamento
    print("\n1. Criando orçamento de teste...")
    numero = exemplo_criar_orcamento_interface()
    
    if not numero:
        return
    
    # 2. Listar orçamentos pendentes
    print("\n2. Orçamentos pendentes:")
    for orc in listar_orcamentos_por_status("Pendente"):
        print(f"- {orc['Número']} | {orc['Cliente']} | R$ {orc['Valor Total']}")
    
    # 3. Aprovar orçamento
    print(f"\n3. Aprovando orçamento {numero}...")
    if aprovar_orcamento(numero, "Dr. José Silva"):
        print(f"Orçamento {numero} aprovado com sucesso!")
    else:
        print(f"Erro ao aprovar orçamento {numero}.")
        return
    
    # 4. Converter em OS
    print(f"\n4. Convertendo orçamento {numero} em OS...")
    numero_os = f"OS{datetime.now().strftime('%y%m%d%H%M')}"
    
    if converter_orcamento_em_os(numero, numero_os, "Dr. José Silva"):
        print(f"Orçamento {numero} convertido em OS {numero_os} com sucesso!")
        
        # 5. Obter dados para inicializar a OS
        print("\n5. Dados extraídos para criação da OS:")
        dados_os = obter_dados_para_os(numero)
        if dados_os:
            print(f"Cliente: {dados_os['cliente']}")
            print(f"Equipamento: {dados_os['equipamento']}")
            print(f"Valor total: R$ {dados_os['valor_total']}")
            print("Itens:")
            for item in dados_os['itens']:
                print(f"  - {item['quantidade']}x {item['descricao']} ({item['tipo']}): R$ {item['valor']}")
    else:
        print(f"Erro ao converter orçamento {numero} em OS.")

# Para teste direto do módulo
if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "teste":
        exemplo_fluxo_completo()
    else:
        print("Módulo de integração de orçamentos carregado.")
        print("Use 'python integracao_orcamentos.py teste' para executar um fluxo de teste completo.") 